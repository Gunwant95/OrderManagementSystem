MVC3-Order-Management-System
============================

This is a demo e-commerce website built using ASP.NET MVC3 in Visual Studio 2010.
Users can browse & buy products, and also save to cart for later purchases. 
Administrators can add new products.
A Demo Checkout system is implemented. (No Paypal intergration has been done). 

Language: C#. 

Also used: HTML5, CSS, JavaScript, jQuery, SQL, Enterprise Library 5.
